function scrollPlotSixDOF(crossData, relativeData, color1, color2, plotTitle, position, subPlotPosition, k, windowlength)

    % Scroll Plot
    subaxis(3,2,subPlotPosition*2, 'Spacing', 0.05, 'Padding', 0, 'Margin', 0, 'PaddingTop', 0.03, 'PaddingLeft', 0, 'MarginLeft', 0, 'PaddingRight', 0.04);
    set(subaxis(3,2,subPlotPosition*2), 'Position', position);
    [AX,H1,H2] = plotyy(k-(windowlength/2):k+(windowlength/2), relativeData(k:k+windowlength), k-(windowlength/2):k+(windowlength/2), crossData(k:k+windowlength));
    
    set(get(AX(1),'Ylabel'),'string','H .  C r o s s   A n g l e   ( d e g )')
    set(get(AX(2),'Ylabel'),'string','R e l a t i v e   A n g l e   ( d e g )') 
    
    set(AX(1),'YColor', color1)
    set(AX(2),'YColor', color2)
    
    set(H1,'color',color2,'linewidth',2)
    set(H2,'color',color1,'linewidth',2)
    
    axis normal
    grid on
    
    set(AX,'YLim',[-20 20])
    set(AX,'YTick',-20:5:20)
    if gt(max(abs(crossData)), 20)||gt(max(abs(relativeData)), 20),
        set(AX,'YLim',[-40 40])
        set(AX,'YTick',-40:10:40)
    end
    if gt(max(abs(crossData)), 40)||gt(max(abs(relativeData)), 40),
        set(AX,'YLim',[-60 60])
        set(AX,'YTick',-60:10:60)
    end  
    if gt(max(abs(crossData)), 60)||gt(max(abs(relativeData)), 60),
        set(AX,'YLim',[-90 90])
        set(AX,'YTick',-90:15:90)
    end
    
    SAT = title(plotTitle);
    set(SAT, 'FontSize', 12)
  
    xlabh = xlabel('Time t (seconds)');
    
    j = 25*(ceil(k/25.));
    set(AX,'XLim',[k-(windowlength/2) k+(windowlength/2)])
    set(AX,'XTick',mod(j-(windowlength/2):25:j+(windowlength/2), 25)+j-(windowlength/2):25:j+(windowlength/2))
    set(AX,'XTickLabel',(mod(j-(windowlength/2):25:j+(windowlength/2), 25)+j-(windowlength/2):25:j+(windowlength/2))/25)
    set(AX, 'nextplot','replacechildren');

    % vertical and horizontal reference lines
    vline(k, 'r');
    HL = refline(0, 0);   
    set(HL, 'Color', 'k');
    
end
