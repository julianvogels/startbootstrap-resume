% movie export and playback script
function videoexportFSR(data, frames, windowlength, filename)

if mod(windowlength, 2)~=0,
    disp('ERROR: windowsize must be an even integer');
    return
end

if windowlength>frames,
    disp('ERROR: windowlength can''t exceed number of frames');
    return
end

if isempty(filename),
    filename = 'out.avi';
end

% prepare data array
prepArray = NaN((windowlength/2), 1);
appArray  = NaN((windowlength/2), 1);
data = [prepArray; data(1:frames); appArray];
disp(['Data peak:', max(data)])

% set up the video
writerObj = VideoWriter(filename, 'Motion JPEG AVI');
writerObj.FrameRate = 25;
open(writerObj);
fid = figure; 
set (fid, 'Position', [100 100 1280 720]);
set(gcf, 'Color','white')

for k = 1:frames
    figure(fid);
    plot(k-(windowlength/2):k+(windowlength/2), data(k:k+windowlength), 'LineWidth',2);

    axis normal
    grid on
    ylim([0 ceil(max(data))]);
    xlim([k-(windowlength/2) k+(windowlength/2)]);
    title('FSR Voltage / Finger Pressure');
    xlabel('Time t (seconds)');
    j = 25*(ceil(k/25.));
    set(gca,'XTick',mod(j-(windowlength/2):25:j+(windowlength/2), 25)+j-(windowlength/2):25:j+(windowlength/2))
    set(gca,'XTickLabel',(mod(j-(windowlength/2):25:j+(windowlength/2), 25)+j-(windowlength/2):25:j+(windowlength/2))/25)
    ylabel('Voltage V');
    set(gca, 'nextplot','replacechildren');
   
    vline(k, 'r');

    %if mod(i,4)==0, % Uncomment to take 1 out of every 4 frames.
        frame = getframe(gcf); % 'gcf' can handle if you zoom in to take a movie.
        writeVideo(writerObj, frame);
    %end
end

close(fid);
close(writerObj); % Saves the movie.