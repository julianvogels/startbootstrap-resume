function fingerPressure(pathname, filename)

            mocap = mcread(fullfile(pathname, filename));

            %resampling analog data
            analogFs = 48000;
            frameRate = 25;

            %resampling calculation
            [P,Q] = rat(frameRate/analogFs);
            abs(P/Q*analogFs-frameRate);
            analog25 = resample(mocap.analogdata, P, Q);
            % export video with data, frames, window[8s], filename

            filename_ext = strcat(strrep(filename, '.mat', ''), '_a0.avi');

            videoexportFSR(analog25, length(analog25), 100, filename_ext)
end