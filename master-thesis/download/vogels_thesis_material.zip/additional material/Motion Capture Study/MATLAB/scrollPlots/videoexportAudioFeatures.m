% movie export and playback script
function videoexportAudioFeatures(rms25, f25, b25, c25, r25, alog25, p25, frames, windowlength, filename)

if mod(windowlength, 2)~=0,
    disp('ERROR: windowsize must be an even integer');
    return
end

if windowlength>frames,
    disp('ERROR: windowlength can''t exceed number of frames');
    return
end

if isempty(filename),
    filename = 'out.avi';
end

% prepare data array
prepArray = NaN((windowlength/2), 1);
appArray = NaN((windowlength/2), 1);

paddedRMS        =    [prepArray; rms25'; appArray];
paddedFlux       =    [prepArray; f25'; appArray];
paddedBrightness =    [prepArray; b25'; appArray];
paddedCentroid   =    [prepArray; c25'; appArray];
paddedRoughness  =    [prepArray; r25'; appArray];
paddedLogAttack  =    [prepArray; alog25'; appArray];
paddedPitch      =    [prepArray; p25'; appArray];

% set up the video and figure
writerObj = VideoWriter(filename);
writerObj.FrameRate = 25;
open(writerObj);
fid = figure; 
set (fid, 'Position', [100 100 1280 720]);
% set(gcf, 'Color','white')

for k = 1:frames
    figure(fid);
    
    % RMS plot
    subaxis(3,2,1, 'SpacingVert', 0.08, 'Padding', 0, 'Margin', 0.06, 'PaddingTop', 0, 'PaddingLeft', 0.08, 'MarginLeft', 0, 'PaddingRight', 0);
    plot(k-(windowlength/2):k+(windowlength/2), paddedRMS(k:k+windowlength), 'color','r','linewidth',1);


    axis normal
    grid on
    xlim([k-(windowlength/2) k+(windowlength/2)]);
    ylim([floor(min(rms25)/100000)*100000 ceil(max(rms25)/100000)*100000]);
    t1 = title('RMS Energy (Root Mean Square)');
    set(t1, 'FontSize', 16, 'FontWeight', 'bold');
    xlabel('Time t (seconds)');
    set(gca, 'YTickLabel', num2str(get(gca, 'YTick')'))
    j = 25*(ceil(k/25.));
    set(gca,'XTick',mod(j-(windowlength/2):25:j+(windowlength/2), 25)+j-(windowlength/2):25:j+(windowlength/2))
    set(gca,'XTickLabel',(mod(j-(windowlength/2):25:j+(windowlength/2), 25)+j-(windowlength/2):25:j+(windowlength/2))/25)
    ylabel('coefficient value');
    set(gca, 'nextplot','replacechildren');
   
    vline(k, 'r'); 
    
    
    % Pitch plot
    subaxis(3,2,2, 'SpacingVert', 0.08, 'Padding', 0, 'Margin', 0.06, 'PaddingTop', 0, 'PaddingLeft', 0.08, 'MarginLeft', 0, 'PaddingRight', 0);
    plot(k-(windowlength/2):k+(windowlength/2), paddedPitch(k:k+windowlength), 'color','b','linewidth',1);

    axis normal
    grid on
    t2 = title('Estimated Pitch Height');
    set(t2, 'FontSize', 16, 'FontWeight', 'bold');
    
    xlim([k-(windowlength/2) k+(windowlength/2)]);
    ylim([floor(min(p25)/10)*10 ceil(max(p25)/10)*10]);
    
    xlabel('Time t (seconds)');
    set(gca, 'YTickLabel', num2str(get(gca, 'YTick')'))
    j = 25*(ceil(k/25.));
    set(gca,'XTick',mod(j-(windowlength/2):25:j+(windowlength/2), 25)+j-(windowlength/2):25:j+(windowlength/2))
    set(gca,'XTickLabel',(mod(j-(windowlength/2):25:j+(windowlength/2), 25)+j-(windowlength/2):25:j+(windowlength/2))/25)
    ylabel('coefficient value (in Hz)');
    set(gca, 'nextplot','replacechildren');
   
    vline(k, 'r');
    
    % Centroid plot
    subaxis(3,2,3, 'SpacingVert', 0.08, 'Padding', 0, 'Margin', 0.06, 'PaddingTop', 0, 'PaddingLeft', 0.08, 'MarginLeft', 0, 'PaddingRight', 0);
    
    wts = [1/48;repmat(1/24,23,1);1/48];
    Ys = conv(paddedCentroid(k:k+windowlength),wts,'valid');
    
    [AX,H1,H2] = plotyy(k-(windowlength/2):k+(windowlength/2), paddedCentroid(k:k+windowlength), k-(windowlength/2)+12:k+(windowlength/2)-12, Ys);
    
    set(get(AX(1),'Ylabel'),'string','coefficient value')
    set(get(AX(2),'Ylabel'),'string','25-point moving average') 
    
    set(AX(1),'YColor', 'g')
    set(AX(2),'YColor', 'k')
    
    set(H1,'color','g','linewidth',1)
    set(H2,'color','k','linewidth',1)
      
    axis normal
    grid on
    
    t3 = title('Spectral Centoid');
    set(t3, 'FontSize', 16, 'FontWeight', 'bold');
    
    set(AX,'XLim',[k-(windowlength/2) k+(windowlength/2)])
    set(AX,'YLim',[floor(min(c25)/100)*100 ceil(max(c25)/100)*100])
    set(AX,'YTick', floor(min(c25)/1000)*1000:1000:ceil(max(c25)/1000)*1000)
    
    xlabel('Time t (seconds)');
    set(gca, 'YTickLabel', num2str(get(gca, 'YTick')'))

    j = 25*(ceil(k/25.));
    set(AX,'XLim',[k-(windowlength/2) k+(windowlength/2)])
    set(AX,'XTick',mod(j-(windowlength/2):25:j+(windowlength/2), 25)+j-(windowlength/2):25:j+(windowlength/2))
    set(AX,'XTickLabel',(mod(j-(windowlength/2):25:j+(windowlength/2), 25)+j-(windowlength/2):25:j+(windowlength/2))/25)
    set(AX, 'nextplot','replacechildren');

    vline(k, 'r');   
    
       
    % Brightness plot
    subaxis(3,2,4, 'SpacingVert', 0.08, 'Padding', 0, 'Margin', 0.06, 'PaddingTop', 0, 'PaddingLeft', 0.08, 'MarginLeft', 0, 'PaddingRight', 0);
    plot(k-(windowlength/2):k+(windowlength/2), paddedBrightness(k:k+windowlength), 'color','g','linewidth',1);

    axis normal
    grid on
    t4 = title('Spectral Brightness');
    set(t4, 'FontSize', 16, 'FontWeight', 'bold');
    
    xlim([k-(windowlength/2) k+(windowlength/2)]);
    ylim([floor(min(b25)) ceil(max(b25))]);
    
    set(gca, 'YTickLabel', num2str(get(gca, 'YTick')'))
    xlabel('Time t (seconds)');
    j = 25*(ceil(k/25.));
    set(gca,'XTick',mod(j-(windowlength/2):25:j+(windowlength/2), 25)+j-(windowlength/2):25:j+(windowlength/2))
    set(gca,'XTickLabel',(mod(j-(windowlength/2):25:j+(windowlength/2), 25)+j-(windowlength/2):25:j+(windowlength/2))/25)
    ylabel('coefficient value');
    set(gca, 'nextplot','replacechildren');
   
    vline(k, 'r');
    
    % Roughness plot
    subaxis(3,2,5, 'SpacingVert', 0.08, 'Padding', 0, 'Margin', 0.06, 'PaddingTop', 0, 'PaddingLeft', 0.08, 'MarginLeft', 0, 'PaddingRight', 0);
    plot(k-(windowlength/2):k+(windowlength/2), paddedRoughness(k:k+windowlength), 'color','g','linewidth',1);

    axis normal
    grid on
    t5 = title('Spectral Roughness');
    set(t5, 'FontSize', 16, 'FontWeight', 'bold');
    
    xlim([k-(windowlength/2) k+(windowlength/2)]);
    ylim([floor(min(r25)/100)*100 ceil(max(r25)/100)*100]);
    
%     set(gca, 'YTickLabel', num2str(get(gca, 'YTick')'))
    xlabel('Time t (seconds)');
    j = 25*(ceil(k/25.));
    set(gca,'XTick',mod(j-(windowlength/2):25:j+(windowlength/2), 25)+j-(windowlength/2):25:j+(windowlength/2))
    set(gca,'XTickLabel',(mod(j-(windowlength/2):25:j+(windowlength/2), 25)+j-(windowlength/2):25:j+(windowlength/2))/25)
    ylabel('coefficient value');
    set(gca, 'nextplot','replacechildren');
   
    vline(k, 'r');
    
    % Flux plot
    subaxis(3,2,6, 'SpacingVert', 0.08, 'Padding', 0, 'Margin', 0.06, 'PaddingTop', 0, 'PaddingLeft', 0.08, 'MarginLeft', 0, 'PaddingRight', 0);
    plot(k-(windowlength/2):k+(windowlength/2), paddedFlux(k:k+windowlength), 'color','g','linewidth',1);

    axis normal
    grid on
    t6 = title('Spectral Flux');
    set(t6, 'FontSize', 16, 'FontWeight', 'bold');
    
    xlim([k-(windowlength/2) k+(windowlength/2)]);
    ylim([floor(min(f25)/100)*100 ceil(max(f25)/100)*100]);
    
    set(gca, 'YTickLabel', num2str(get(gca, 'YTick')'))
    xlabel('Time t (seconds)');
    j = 25*(ceil(k/25.));
    set(gca,'XTick',mod(j-(windowlength/2):25:j+(windowlength/2), 25)+j-(windowlength/2):25:j+(windowlength/2))
    set(gca,'XTickLabel',(mod(j-(windowlength/2):25:j+(windowlength/2), 25)+j-(windowlength/2):25:j+(windowlength/2))/25)
    ylabel('coefficient value');
    set(gca, 'nextplot','replacechildren');
   
    vline(k, 'r');
    
    % Log Attack plot
%     subaxis(3,2,6, 'SpacingVert', 0.08, 'Padding', 0, 'Margin', 0.06, 'PaddingTop', 0, 'PaddingLeft', 0.08, 'MarginLeft', 0, 'PaddingRight', 0);
%     plot(k-(windowlength/2):k+(windowlength/2), paddedLogAttack(k:k+windowlength), 'color','g','linewidth',1);
% 
%     axis normal
%     grid on
%     t6 = title('Log Attack Time');
%     set(t6, 'FontSize', 16, 'FontWeight', 'bold');
%     
%     xlim([k-(windowlength/2) k+(windowlength/2)]);
%     ylim([floor(min(f25)/100)*100 ceil(max(f25)/100)*100]);
%     
%     set(gca, 'YTickLabel', num2str(get(gca, 'YTick')'))
%     xlabel('Time t (seconds)');
%     j = 25*(ceil(k/25.));
%     set(gca,'XTick',mod(j-(windowlength/2):25:j+(windowlength/2), 25)+j-(windowlength/2):25:j+(windowlength/2))
%     set(gca,'XTickLabel',(mod(j-(windowlength/2):25:j+(windowlength/2), 25)+j-(windowlength/2):25:j+(windowlength/2))/25)
%     ylabel('coefficient value');
%     set(gca, 'nextplot','replacechildren');
%    
%     vline(k, 'r');
%     
    % Capture the frame
    frame = getframe(gcf); 
    writeVideo(writerObj, frame);
    
end

close(fid);
close(writerObj); % Saves the movie.