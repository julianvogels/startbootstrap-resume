% movie export and playback script
function videoexport(data, frames, windowlength, filename)

if mod(windowlength, 2)~=0,
    disp('ERROR: windowsize must be an even integer');
    return
end

if windowlength>frames,
    disp('ERROR: windowlength can''t exceed number of frames');
    return
end

if isempty(filename),
    filename = 'out.avi';
end

disp('Data peak:'+max(data))

% prepare data array
prepArray = zeros((windowlength/2), 1);
appArray = zeros((windowlength/2), 1);
data = [prepArray; data(1:frames); appArray];

% set up the video
writerObj = VideoWriter(filename); % Name it.
writerObj.FrameRate = 25;
open(writerObj);
fid = figure; 

for k = 1:frames
    figure(fid);
    plot(k-(windowlength/2):k+(windowlength/2), data(k:k+windowlength));
    
    set(gcf, 'Color','white')
    axis normal
    grid on
    ylim([0 2]);
    xlim([k-(windowlength/2) k+(windowlength/2)]);
    title('FSR Voltage / Finger Pressure');
    xlabel('Time t');
    ylabel('Voltage V');
    set(gca, 'nextplot','replacechildren');
   
    vline(k, 'r');

    %if mod(i,4)==0, % Uncomment to take 1 out of every 4 frames.
        frame = getframe(gcf); % 'gcf' can handle if you zoom in to take a movie.
        writeVideo(writerObj, frame);
    %end
end

close(writerObj); % Saves the movie.