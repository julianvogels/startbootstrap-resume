function sixDOF(pathname, filename)
        sixDOFTotal = dlmread(fullfile(pathname, filename), '\t');
        totalSize = size(sixDOFTotal);
        totalColumns = totalSize(2);
        
%         mocap = mcread(fullfile(pathname, filename));
%         head = mcgetmarker(mocap, 5:12);
%         
%         poly3d = mocap.data((3*4+1)+3*2:(3*4+1)+3*2+3*3);
        
        if lt(totalColumns, 34),
            disp('no head band data, will continue to next file if applicable')
            return
        else
        sixDOFHarmonicaCross = sixDOFTotal(:,1:17);
        sixDOFHeadBand = sixDOFTotal(:,18:34);
        
        %resampling analog data
        qualisysFs = 240;
        frameRate = 25;

        %resampling calculation
        [P,Q] = rat(frameRate/qualisysFs); 
        abs(P/Q*qualisysFs-frameRate);

        crossRoll25  =  resample(sixDOFHarmonicaCross(:,4), P, Q);
        crossPitch25 =  resample(sixDOFHarmonicaCross(:,5), P, Q);
        crossYaw25   =  resample(sixDOFHarmonicaCross(:,6), P, Q);
        
        bandRoll25   =  resample(sixDOFHeadBand(:,4), P, Q);
        bandPitch25  =  resample(sixDOFHeadBand(:,5), P, Q);
        bandYaw25    =  resample(sixDOFHeadBand(:,6), P, Q);
        
        % reverse Pitch angle
        crossPitch25 =  crossPitch25.*(-1);
        bandPitch25  =  bandPitch25.*(-1);
        
        % reverse Yaw angle
        crossYaw25   =  crossYaw25.*(-1);
        bandYaw25    =  bandYaw25.*(-1);
                
        cookedSixDOFCross = [crossRoll25 crossPitch25 crossYaw25];        
        cookedSixDOFHeadBand = [bandRoll25 bandPitch25 bandYaw25];
        
        % export video with data, frames, window[8s], filename

        filename_ext = strcat(strrep(filename, '.tsv', ''), '_6DOF.avi');
        
        videoexportDOF(cookedSixDOFCross, cookedSixDOFHeadBand, length(cookedSixDOFCross), 100, filename_ext);
        end
end