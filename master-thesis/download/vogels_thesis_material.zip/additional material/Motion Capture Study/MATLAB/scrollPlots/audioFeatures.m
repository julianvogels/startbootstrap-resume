function audioFeatures(pathname, filename)
%% read file
% get number of samples
siz = aiffread(fullfile(pathname, filename),'size');
sampleCount = siz(1);

%% mirtoolbox calculations
% read audio file into mirToolbox
audioFile = miraudio(fullfile(pathname, filename));

% DYNAMIC %

    % Global energy
    rms = mirrms(audioFile, 'Frame');
    rmsData = mirgetdata(rms);
    
    
% TIMBRE %

    % Spectral Flux
    s = mirspectrum(audioFile, 'Frame');
    f = mirflux(s);
    fData = mirgetdata(f);

    %Spectral Brightness
    b = mirbrightness(audioFile, 'Frame');
    bData = mirgetdata(b);

    % Spectral Centroid
    c = mircentroid(audioFile, 'Frame');
    cData = mirgetdata(c);

    % Spectral Roughness / Jaggedness
    r = mirroughness(audioFile);
    rData = mirgetdata(r);

    % Log Attack
    alog = mirattackslope(audioFile);
    alogData = mirgetdata(alog);

% PITCH %

    p = mirpitch(audioFile, 'Frame');
    pData = mirgetdata(p);

% For hand cupping ?
% p = mirpulseclarity(audioFile, 'Frame')

% video export

%% resampling 
% resampling preparation
Fs = 48000;
totalSeconds = siz(1)/Fs;
frameRate = 25;

%resampling RMS
rmsFs = length(rmsData)/totalSeconds;
[P,Q] = rat(frameRate/rmsFs);
rms25 = resample(rmsData, P, Q);

%resampling Flux
fFs = length(fData)/totalSeconds;
[P,Q] = rat(frameRate/fFs);
f25 = resample(fData, P, Q);

%resampling Brightness
bFs = length(bData)/totalSeconds;
[P,Q] = rat(frameRate/bFs);
b25 = resample(bData, P, Q);

%resampling Centroid
cFs = length(cData)/totalSeconds;
[P,Q] = rat(frameRate/cFs);
c25 = resample(cData, P, Q);

%resampling Roughness
rFs = length(rData)/totalSeconds;
[P,Q] = rat(frameRate/rFs);
r25 = resample(rData, P, Q);

%resampling A Log
alogFs = length(alogData)/totalSeconds;
[P,Q] = rat(frameRate/alogFs);
alog25 = resample(alogData, P, Q);

%resampling Pitch
pFs = length(pData)/totalSeconds;
[P,Q] = rat(frameRate/pFs);
p25 = resample(pData, P, Q);

%% videoexport

filename_ext = strcat(strrep(filename, '.aif', ''), '_audioFeatures.avi');

            
videoexportAudioFeatures(rms25, f25, b25, c25, r25, alog25, p25, sampleCount/48000*25, 200, filename_ext)

end