    % Pitch Scroll Plot
    sa5 = subaxis(3,2,4, 'Spacing', 0.05, 'Padding', 0, 'Margin', 0, 'PaddingTop', 0.03, 'PaddingLeft', 0, 'MarginLeft', 0, 'PaddingRight', 0.02);
    set(sa5, 'Position', [0.20, 0.37, 0.79, 0.26]);
    sp5 = plot(k-(windowlength/2):k+(windowlength/2), paddedCrossPitch(k:k+windowlength));
    set(sp5,'color','g','linewidth',2)    
    axis normal
    grid on
    ylim([-20 20]);
    if gt(max(abs(paddedCrossPitch)), 20)
        ylim([-40 40]);
    end
    if gt(max(abs(paddedCrossPitch)), 40)
        ylim([-60 60]);
    end  
    if gt(max(abs(paddedCrossPitch)), 60)
        ylim([-90 90]);
    end
    xlim([k-(windowlength/2) k+(windowlength/2)]);
    sa5t = title('Pitch scroll plot');
    set(sa5t, 'FontSize', 12)
    xlabel('Time t (seconds)');
    j = 25*(ceil(k/25.));
    set(gca,'XTick',mod(j-(windowlength/2):25:j+(windowlength/2), 25)+j-(windowlength/2):25:j+(windowlength/2))
    set(gca,'XTickLabel',(mod(j-(windowlength/2):25:j+(windowlength/2), 25)+j-(windowlength/2):25:j+(windowlength/2))/25)
    ylabel('Angle a (degrees)');
    set(gca, 'nextplot','replacechildren');
    vline(k, 'r');
    hl5 = refline(0, 0);   
    set(hl5, 'Color', 'k');