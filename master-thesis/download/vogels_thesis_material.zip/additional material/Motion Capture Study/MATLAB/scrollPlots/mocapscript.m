% HARMONICA STUDY DEC-FEB 2013/2014 
%
% Author: Julian Vogels
% Institution: Input Devices and Music Interaction Lab, McGill University
% Montreal
%
% Script used to display and export data from Qualisys motion capture
% matlab file


prompt = '\nPlease choose a menu number: \n\n1. Finger pressure data video export\n2. Inclination of Harmonica (and in relation to head)\n3. Distance of Center of mean plane of finger movement to harmonica center line\n4. Extract Audio Features\n5. Distance between CHEEK and CHIN marker\n6. Frequency of hand cupping gesture\n\nInput: ';
result = input(prompt);
switch result
    case 1
        batch = input('You chose finger pressure data.  Press 1 to select a file, press 2 to select a directory for batch processing: \n');

        switch batch
            case 1
                [filename, pathname] = uigetfile('*.mat', 'Select a MATLAB matrix file', '/Volumes/Data HD/Master''s Thesis/Motion Capture Study/201402_Harmonica_Vogels/Data/mat');
                if isequal(filename,0)
                   disp('You pressed cancel. Quitting...')
                   return
                else
                   disp(['Selected file: ', fullfile(pathname, filename)])
                end
            case 2
                % batch processing
                 disp('You selected batch processing. The current working directory will be used.\n')
            otherwise
                disp('your argument is invalid. All your base are belong to us now.');
                return
        end

        if isequal(batch, 1)
            % one file processing
            fingerPressure(pathname, filename);
        else
            % batch processing
            disp('batch processing finger pressure data...')
            files = dir('*.mat');
            noOfFiles = length(files);
            i = 0;
            for file = files'
                i = i+1;
                disp(['Processing file:', file.name])
                disp(['File no. ',num2str(i(1)),' of ',num2str(noOfFiles(1))])
                fingerPressure(pwd, file.name);
            end
        end
        break
        
    case 2
        batch = input('You chose harmonica inclination. Press 1 to select a file, press 2 to select a directory for batch processing: \n');

        switch batch
            case 1
                [filename, pathname] = uigetfile('*.tsv', 'Select a TAB SEPARATED VALUES (TSV) file', '/Volumes/Data HD/Master''s Thesis/Motion Capture Study/201402_Harmonica_Vogels/Data/6DOF_globalOrigin_noHeader/');
                if isequal(filename,0)
                   disp('You pressed cancel. Quitting...')
                   return
                else
                   disp(['Selected file: ', fullfile(pathname, filename)])
                   % one file processing
                    sixDOF(pathname, filename);
                end
            case 2
                % batch processing
                disp(['You selected batch processing. The current working directory will be used: ' pwd])
                filesTSV = dir('*.tsv');
                noOfFilesTSV = length(filesTSV);
                i2 = 0;
                for file = filesTSV'
                    i2 = i2+1;
                    disp(['Processing file:', file.name])
                    disp(['File no. ',num2str(i2(1)),' of ',num2str(noOfFilesTSV(1))])
                    sixDOF(pwd, file.name);
                end
            otherwise
                disp('your argument is invalid. All your base are belong to us now.');
                return
        end
        break
    case 3
        disp('You chose distance for hand cupping. This feature is not yet available.')
        break
    case 4
        batch = input('You chose audio feature export. Press 1 to select a file, press 2 to select a directory for batch processing: \n');

        switch batch
            case 1
                [filename, pathname] = uigetfile('*.aif', 'Select a AIF audio file', '/Volumes/Data HD/Master''s Thesis/Motion Capture Study/audio_for_feature_extraction/');
                if isequal(filename,0)
                   disp('You pressed cancel. Quitting...')
                   return
                else
                   disp(['Selected file: ', fullfile(pathname, filename)])
                end
            case 2
                % batch processing
                 disp('You selected batch processing. The current working directory will be used.\n')
            otherwise
                disp('your argument is invalid. All your base are belong to us now.');
                return
        end
        
        if isequal(batch, 1)
            % one file processing
            audioFeatures(pathname, filename);
        else
            % batch processing
            files = dir('*.tsv');
            for file = files'
                audioFeatures(pwd, file.name);
            end
        end
        break
    case 5
        disp('You chose distance of CHIN marker and CHEEK marker.')
        % mcmarkerdist TODO
        break
    case 6
        disp('You chose frequency of hand cupping gesture. Please select your file.')
        [filename, pathname] = uigetfile('*.mat', 'Select a MATLAB matrix file', '/Volumes/Data HD/Master''s Thesis/Motion Capture Study/201402_Harmonica_Vogels/Data/mat');
                if isequal(filename,0)
                   disp('You pressed cancel. Quitting...')
                   return
                else
                   disp(['Selected file: ', fullfile(pathname, filename)])
                   [mocap, frequency, dataArray] = handCuppingFrequency(pathname, filename);
                end
        break
    otherwise
        disp('your entry is not valid')
        break
end
