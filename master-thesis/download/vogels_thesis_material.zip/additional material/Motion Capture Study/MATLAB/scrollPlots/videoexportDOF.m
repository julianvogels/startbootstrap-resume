% movie export and playback script
function videoexportDOF(cross, headband, frames, windowlength, filename)

if mod(windowlength, 2)~=0,
    disp('ERROR: windowsize must be an even integer');
    return
end

if windowlength>frames,
    disp('ERROR: windowlength can''t exceed number of frames');
    return
end

if isempty(filename),
    filename = 'out.avi';
end

% prepare data array
prepArray = NaN((windowlength/2), 1);
appArray  = NaN((windowlength/2), 1);

crossRoll  = cross(1:frames, 1);
crossPitch = cross(1:frames, 2);
crossYaw   = cross(1:frames, 3);

paddedCrossRoll  =    [prepArray; crossRoll; appArray];
paddedCrossPitch =    [prepArray; crossPitch; appArray];
paddedCrossYaw   =    [prepArray; crossYaw; appArray];

relativeRoll  = crossRoll   -   headband(1:frames, 1);
relativePitch = crossPitch  -   headband(1:frames, 2);
relativeYaw   = crossYaw    -   headband(1:frames, 3);

paddedRelativeRoll  =  [prepArray; relativeRoll; appArray];
paddedRelativePitch =  [prepArray; relativePitch; appArray];
paddedRelativeYaw   =  [prepArray; relativeYaw; appArray];

% set up the video and figure
writerObj = VideoWriter(filename);
writerObj.FrameRate = 25;
open(writerObj);
fid = figure; 
set (fid, 'Position', [100 100 1280 720]);
% set(gcf, 'Color','white')

% Offset amount for the Roll, Pitch and Yaw labels
labelXOffset = -0.4;
labelYOffset = -1.3;

colorRoll = 'c';
colorPitch = 'b';
colorYaw = 'r';
colorMean = 'g';

for k = 1:frames
    figure(fid);
    
    % Roll plot
    sa1 = subaxis(3,2,1, 'Spacing', 0.05, 'Padding', 0, 'Margin', 0, 'PaddingTop', 0.03, 'MarginRight', 0, 'PaddingRight', 0);
    set(sa1, 'Position', [0.02, 0.69, 0.20, 0.27]);
    [x,y] = pol2cart([(relativeRoll(k).*pi/180) (crossRoll(k).*pi/180)],1);
    h1 = compass(x,y);
    set(h1(1),'color',colorMean,'linewidth',2)
    set(h1(2),'color',colorRoll,'linewidth',2)
    h1Title = title('Roll');
    h1TitleP = get(h1Title,'Position');
    set(h1Title,'Position',[h1TitleP(1)+labelXOffset h1TitleP(2)+labelYOffset h1TitleP(3)])
    set(h1Title, 'FontSize', 16);
    set(h1Title, 'FontWeight', 'bold');
    set(findall(gcf, 'String', '120', '-or','String','150', '-or','String','180', '-or','String','210', '-or','String','240', '-or','String','0.5', '-or','String','1') ,'String', '  ');
    set(findall(gcf, 'String', '330') ,'String', '-30');
    set(findall(gcf, 'String', '300') ,'String', '-60');
    set(findall(gcf, 'String', '270') ,'String', '-90');
    xlim([0 pi/2])
    
    % Pitch plot
    sa2 = subaxis(3,2,3, 'Spacing', 0.05, 'Padding', 0, 'Margin', 0);
    set(sa2, 'Position', [0.02, 0.36, 0.20, 0.27]);
    [x,y] = pol2cart([(relativePitch(k).*pi/180) (crossPitch(k).*pi/180)],1);
    h2 = compass(x,y);
    set(h2(1),'color',colorMean,'linewidth',2)
    set(h2(2),'color',colorPitch,'linewidth',2)
    h2Title = title('Pitch');
    h2TitleP = get(h2Title,'Position');
    set(h2Title,'Position',[h2TitleP(1)+labelXOffset-0.1 h2TitleP(2)+labelYOffset h2TitleP(3)])
    set(h2Title, 'FontSize', 16);
    set(h2Title, 'FontWeight', 'bold');
    set(findall(gcf, 'String', '120', '-or','String','150', '-or','String','180', '-or','String','210', '-or','String','240') ,'String', '  ');
    set(findall(gcf, 'String', '330') ,'String', '-30');
    set(findall(gcf, 'String', '300') ,'String', '-60');
    set(findall(gcf, 'String', '270') ,'String', '-90');
    xlim([0 pi/2])
    
    % Yaw plot
    sa3 = subaxis(3,2,5, 'Spacing', 0.05, 'Padding', 0, 'Margin', 0);
    set(sa3, 'Position', [0.02, 0.03, 0.20, 0.27]);
    [x,y] = pol2cart([(relativeYaw(k).*pi/180) (crossYaw(k).*pi/180)],1);
    h3 = compass(x,y);
    set(h3(1),'color',colorMean,'linewidth',2)
    set(h3(2),'color',colorYaw,'linewidth',2)
    h3Title = title('Yaw');
    h3TitleP = get(h3Title,'Position');
    set(h3Title,'Position',[h3TitleP(1)+labelXOffset h3TitleP(2)+labelYOffset h3TitleP(3)])
    set(h3Title, 'FontSize', 16);
    set(h3Title, 'FontWeight', 'bold');
    set(findall(gcf, 'String', '120', '-or','String','150', '-or','String','180', '-or','String','210', '-or','String','240') ,'String', '  ');
    set(findall(gcf, 'String', '330') ,'String', '-30');
    set(findall(gcf, 'String', '300') ,'String', '-60');
    set(findall(gcf, 'String', '270') ,'String', '-90');
    xlim([0 pi/2])
    
%     Roll Scroll Plot
    scrollPlotSixDOF(paddedCrossRoll, paddedRelativeRoll, colorRoll, colorMean, 'Roll scroll plot', [0.20, 0.71, 0.76, 0.26], 1, k, windowlength);
    
    % Pitch Scroll Plot
    scrollPlotSixDOF(paddedCrossPitch, paddedRelativePitch, colorPitch, colorMean, 'Pitch scroll plot', [0.20, 0.37, 0.76, 0.26], 2, k, windowlength);
    
    % Yaw Scroll Plot
    scrollPlotSixDOF(paddedCrossYaw, paddedRelativeYaw, colorYaw, colorMean, 'Yaw scroll plot', [0.20, 0.04, 0.76, 0.26], 3, k, windowlength);
    
    % Capture the frame
    frame = getframe(gcf); 
    writeVideo(writerObj, frame);
    
end

close(fid);
close(writerObj); % Saves the movie.