function [mocap, frequency, dataArray] = handCuppingFrequency(pathname, filename)
mocap = mcread(fullfile(pathname, filename));
%% Input
disp(mocap.markerName)
prompt = input('Choose marker number:\n');
disp(['You chose marker with name: ', mocap.markerName(prompt)])
mcplottimeseries(mocap, prompt, 'dim', [1 2 3])
prompt2 = input('Input the trim points (in seconds) in the format [x y]:\n');
mocaptrim = mctrim(mocap, prompt2(1), prompt2(2));
mcplottimeseries(mocaptrim, prompt, 'dim', [1 2 3])
onemarkerstruct = mcgetmarker(mocaptrim, prompt);
onemarkervelocity = diff(onemarkerstruct.data(:,1:3));
onemarkercopy = onemarkerstruct;
onemarkercopy.data(:,1:3) = diff(onemarkerstruct.data(:,1:3))
%% Calculation
[per, ac, eac, lag] = mcperiod(onemarkercopy);
per2freq = 1./per;
per2freqMean = mean(per2freq);

delta = 10;

[maxtab1, mintab1] = peakdet(onemarkervelocity(:,1), delta);
[maxtab2, mintab2] = peakdet(onemarkervelocity(:,2), delta);
[maxtab3, mintab3] = peakdet(onemarkervelocity(:,3), delta);

peakdetFreq1 = 1/(length(onemarkervelocity)/240/length(maxtab1));
peakdetFreq2 = 1/(length(onemarkervelocity)/240/length(maxtab2));
peakdetFreq3 = 1/(length(onemarkervelocity)/240/length(maxtab3));
peakdetFreqMean = mean([peakdetFreq1;peakdetFreq2;peakdetFreq3]);
%% Output
disp(['MCPERIOD results: X,Y,Z,Mean ', num2str(per2freq(1)),' ',num2str(per2freq(2)),' ',num2str(per2freq(3)),' ', num2str(per2freqMean)])
disp(['PEAKDET results: X,Y,Z,Mean ', num2str(peakdetFreq1),' ',num2str(peakdetFreq2),' ',num2str(peakdetFreq3),' ', num2str(peakdetFreqMean)])
frequency = mean([per2freqMean;peakdetFreqMean]);
disp(['MEAN FREQ: ',num2str(frequency)])
dataArray = [per2freq(1) per2freq(2) per2freq(3) per2freqMean peakdetFreq1 peakdetFreq2 peakdetFreq3 peakdetFreqMean frequency]

end