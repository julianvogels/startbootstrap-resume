%% Variables
figure
no_participants = 5;
% mcperioddata = [7.62 7.91 7.12 6.82 8.02];
mcperioddata = hCarray(4, :);
% peakdetdata = [7.86 10.16 8.47 7.45 10.29];
peakdetdata = hCarray(8, :);

x = 1:no_participants+1;
y2 = [mcperioddata mean(mcperioddata)];
y1 = [peakdetdata mean(peakdetdata)];

ymaxval = 8.5;
yminval = 6.5;

%% Plot

stem(x, y2, 'MarkerFaceColor','green','Marker','square', 'MarkerEdgeColor', [0 0.4 0], 'Color', [0 0.4 0], 'MarkerSize', 10)
axis([0 no_participants+2 yminval ymaxval])
set(gcf,'color','white')
grid on 
ylabel('Frequency of hand cupping gesture', 'fontsize', 14, 'fontweight', 'bold') 
set(gca,'YLim',[yminval ymaxval])
set(gca, 'YTick', yminval:0.5:ymaxval, 'fontsize', 14)

set(gca,'XLim', [0 no_participants+2] )
set(gca,'XTick', 0:no_participants+1 )
set(gca,'XTickLabel', [{[]} 1:no_participants {'Average'}], 'fontsize', 14)


xlabel('Participant', 'fontsize', 14, 'fontweight', 'bold') 
title(['\fontsize{16}Frequency of fastest possible hand cupping\newlinetremolo measured at position RH4U'], 'fontweight','bold')


%% Plotyy

[AX, H1, H2] = plotyy(x, y1, x, y2, 'stem');
axis([0 no_participants+2 yminval ymaxval])
set(gcf,'color','white')
grid on 
set(get(AX(2),'Ylabel'),'String','A u t o c o r r e l a t i o n   m e t h o d   ( m c p e r i o d )') 
set(get(AX(1),'Ylabel'),'String','P e a k   D e t e c t i o n   m e t h o d   ( p e a k d e t )') 
set(AX,'YLim',[yminval ymaxval])
set(AX, 'YTick', yminval:0.5:ymaxval)

set(AX,'XLim', [0 no_participants+2] )
set(AX,'XTick', 0:no_participants+1 )
set(AX,'XTickLabel', [{[]} 1:no_participants {'Average'}])

set(H1,'MarkerFaceColor','blue')
set(H2,'MarkerFaceColor','green','Marker','square')

xlabel('Participant') 
title('Frequency of fastest possible hand cupping tremolo measured at position RH4U') 