% Script for analysis of cheek-chin (jaw opening) distance versus fundamental frequency
% for the note beding technique applied to a Richter-tuned diatonic
% harmonica

% (c) Julian Vogels 2014
% IDMIL, McGill University

%% TSV file query
[tsvfilename, tsvpathname] = uigetfile('*.tsv', 'Select a TSV file containing cheek-chin distance data', '/Volumes/Data HD/Master''s Thesis/Motion Capture Study/201402_Harmonica_Vogels/Data/tsv');

FID=fopen(fullfile(tsvpathname, tsvfilename),'rt');
distanceData=textscan(FID,'%f','Headerlines',8,'CommentStyle','@');
fclose(FID);
distanceData = cell2mat(distanceData);


%% Sound file query
[soundfilename, soundpathname] = uigetfile('*.aiff', 'Select a AIFF file containing the audio signal', '/Volumes/Data HD/Master''s Thesis/Motion Capture Study/audio_for_feature_extraction');

%% fundamental frequency estimation

% Parameters
if ischar(soundfilename)
    soundfile = fullfile(soundpathname, soundfilename);
else
    soundfile = fullfile('/Volumes/Data HD/Master''s Thesis/Motion Capture Study/Matlab/', '20131213_participant01_scene1_1b.aiff');
end

Fs = 48000;
FsResampled = 24000;

range = [15 27]; %range in seconds
rangeSamps = range.*Fs;

signal = aiffread(soundfile, rangeSamps);

% Signal
signalch1 = double(signal(:, 1)'); % channel 1: mono
signalnorm = signalch1./max(signalch1);

%resampling calculation
[P,Q] = rat(FsResampled/Fs);
abs(P/Q*Fs-FsResampled);
x = resample(signalnorm, P, Q);


%% YIN

%   P.minf0:    Hz - minimum expected F0 (default: 30 Hz)
%   P.maxf0:    Hz - maximum expected F0 (default: SR/(4*dsratio))
%   P.thresh:   threshold (default: 0.1)
%   P.relfag:   if ~0, thresh is relative to min of difference function (default: 1)
%   P.hop:      samples - interval between estimates (default: 32)
%   P.range:    samples - range of samples ([start stop]) to process
%   P.bufsize:  samples - size of computation buffer (default: 10000)
%	P.sr:		Hz - sampling rate (usually taken from file header)
%	P.wsize:	samples - integration window size (defaut: SR/minf0)
%	P.lpf:		Hz - intial low-pass filtering (default: SR/4)
%	P.shift		0: shift symmetric, 1: shift right, -1: shift left (default: 0)

field1 = 'sr';  value1 = FsResampled;
field2 = 'hop';  value2 = 100;
field3 = 'thresh';  value3 = 0.05;
field4 = 'minf0';  value4 = 1000;

P = struct(field1,value1,field2,value2,field3,value3);

R = yin(x', P);

%% YIN+Distance Plot
close all; clc

FigHandle = figure;
  set(FigHandle, 'Position', [100, 100, 800, 600]);

distanceFs = 240;
distanceRangeSamps = range.*distanceFs;
distanceDataTrim = distanceData(distanceRangeSamps(1):distanceRangeSamps(2)-1);

X1 = 1:length(distanceDataTrim);
X2 = 1:length(R.f0);
[AX, H1, H2] = plotyy(X1, distanceDataTrim, X2, R.f0);
% set(AX(2), 'ylim', [nanmean(R.f0)-0.1 nanmean(R.f0)+0.1]);
% set(AX(1), 'Ydir', 'reverse');
set(AX, 'Xtick', 0:distanceFs:distanceRangeSamps(2)-distanceRangeSamps(1));
set(AX, 'Xticklabel', range(1):range(2));
set(AX(2), 'Xtick', []);
ylabel(AX(1), 'D i s t a n c e   b e t w e e n   m a r k e r s   C H E E K   a n d   C H I N   ( m m )');
ylabel(AX(2), 'E s t i m a t e d   f u n d a m e n t a l   f r e q u e n c y   f 0   ( o c t a v e   r e : 4 4 0 H z )');
xlabel(AX(1), 'Time t in seconds');
xlabel(AX(2), '');
set(H1,'Color', 'b');
set(H2,'Color', 'r');
set(AX,{'ycolor'},{'b';'r'})
axis tight

% title(['\fontsize{16}Richter-tuned Harmonica Note Bending: cheek-chin distance vs. f0', ...
%        '\newline\fontsize{10}\color{blue}\it',strrep(tsvfilename, '_', '\_ '),' \color{black}vs.\color{red} ',strrep(soundfilename, '_', '\_ ')
% ], 'Fontweight', 'bold');

% correlation = corr(R.f0', distanceDataTrim);
correlationMatrix = [R.f0(5:length(R.f0)-13)' distanceDataTrim(5:length(distanceDataTrim)-13)];
correlation = corr(correlationMatrix, 'rows','complete');
disp(['Correlation: r:', mat2str(correlation)]);

title(['\fontsize{16}Richter-tuned Harmonica Note Bending: cheek-chin distance vs. f0', ...
    '\newline\fontsize{12}\color{blue}\it Correlation: ',num2str(correlation(2))],'Fontweight', 'bold');
legend(strrep(tsvfilename, '_', '\_ '),strrep(soundfilename, '_', '\_ '))

%make background white
set(gcf, 'color', [1 1 1])

%% Play file

aP = audioplayer(x, FsResampled);
play(aP)
