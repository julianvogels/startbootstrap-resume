%% getfile


% [filename, pathname] = uigetfile('*.tsv', 'Select a TSV file containing 6DOF data', '/Volumes/Data HD/Master''s Thesis/Motion Capture Study/201402_Harmonica_Vogels/Data/6DOF_globalOrigin_noHeader');

%% batch

files = dir('*.tsv');

noOfFiles = length(files);
meanDist = zeros(1, noOfFiles);
stdDist = zeros(1, noOfFiles);

i = 0;

for file = files'
    i = i+1;
    disp(['Processing file:', file.name])
    disp(['File no. ',num2str(i(1)),' of ',num2str(noOfFiles(1))])


    %% input
    FID=fopen(files(2).name,'rt');
    distanceData=textscan(FID,'%f','Headerlines',8,'CommentStyle','@');
    fclose(FID);
    distanceData = cell2mat(distanceData);

    %% trim
    plot(1:length(distanceData), distanceData)
    prompt = input('Input the trim points (in samples) in the format [x y]:\n');

    distanceData = distanceData(prompt(1):prompt(2));
    %% output

    meanDist(i) = mean(crossPitch);
    stdDist(i)  = std(crossPitch);


    writeFileID = fopen('testfile.tsv');
    fprintf(writeFileID,'%12.8f\n', distanceData);
    fclose(writeFileID);


end
            
